import React from "react";

const Developer = () => {
    return (
        <div>Developer</div>
    )
}

export default Developer;