import React from 'react'

const Video = () => {
    return (
        <div>Video</div>
    )
}
    
export default Video;