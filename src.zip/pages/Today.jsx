import React from 'react'

const Today = () => {
    return (
        <div>Today</div>
    )
}
    
export default Today;