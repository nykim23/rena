import React from "react";

const Footer = () => {
    return (
        <Footer id="footer" role="contentinfo">
            footer
        </Footer>
    )
}

export default Footer