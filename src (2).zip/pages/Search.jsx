import React from 'react'
import Main from '../components/section/Main'

const Search = () => {
    return (
        <Main>Search</Main>
    )
}
    
export default Search;