import React from 'react'
import Main from '../components/section/Main'

const Today = () => {
    return (
        <Main>Today</Main>
    )
}
    
export default Today;