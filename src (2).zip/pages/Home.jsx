import React from 'react'
import Main from '../components/section/Main'

const Home = () => {
    return (
        <Main>Home</Main>
    )
}

export default Home;