import React from 'react'
import Main from '../components/section/Main'

const Website = () => {
    return (
        <Main>Website</Main>
    )
}
    
export default Website;