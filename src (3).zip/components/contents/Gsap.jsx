import React from 'react'

const Gsap = () => {
    return (
        <div>Gsap</div>
    )
}

export default Gsap