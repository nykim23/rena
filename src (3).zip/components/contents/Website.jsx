import React from 'react'

const Website = () => {
    return (
        <div>
            Website
        </div>
    )
}

export default Website