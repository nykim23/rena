import React from 'react'
import Main from '../components/section/Main'

const Youtube = () => {
    return (
        <Main>Youtube</Main>
    )
}
    
export default Youtube;