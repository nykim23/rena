import React from 'react'
import Main from '../components/section/Main'

const Webd = () => {
    return (
        <Main>Webd</Main>
    )
}
    
export default Webd;