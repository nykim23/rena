import React from 'react'
import Main from '../components/section/Main'

const Developer = () => {
    return (
        <Main
        title = "추천 개발자"
            description="오늘의 추천 개발자 유튜버입니다.">
            Developer
        </Main>
    )
}

export default Developer