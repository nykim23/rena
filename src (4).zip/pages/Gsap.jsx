import React from "react";
import Main from '../components/section/Main'

const Gsap = () => {
    return (
        <Main>Gsap</Main>
    )
}

export default Gsap;