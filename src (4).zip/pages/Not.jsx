import React from 'react'
import Main from '../components/section/Main'

const Not = () => {
    return (
        <Main>Not</Main>
    )
}
    
export default Not;