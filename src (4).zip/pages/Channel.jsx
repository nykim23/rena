import React from "react";
import Main from '../components/section/Main'

const Channel = () => {
    return (
        <Main
        title="유투브 채널"
        description="유투브 채널페이지">Channel</Main>
    )
}

export default Channel;