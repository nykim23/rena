import React from 'react'
import Main from '../components/section/Main'

const Video = () => {
    return (
        <Main>Video</Main>
    )
}
    
export default Video;