
import youtube01 from "../assets/img/webd/webd01.jpg";
import youtube02 from "../assets/img/webd/webd02.jpg";
import youtube03 from "../assets/img/webd/webd03.jpg";
import youtube04 from "../assets/img/webd/webd04.jpg";
import youtube05 from "../assets/img/webd/webd05.jpg";

export const youtubeText = [
    {
        title: "01 나만의 유튜브 사이트 만들기",
        img: youtube01,
        author: "webstoryboy",
        videoId: "OKZXYgAgtyw",
        date: "2023.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "02 나만의 유튜브 사이트 만들기",
        img: youtube02,
        author: "webstoryboy",
        videoId: "OKZXYgAgtyw",
        date: "2023.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "03 나만의 유튜브 사이트 만들기",
        img: youtube03,
        author: "webstoryboy",
        videoId: "OKZXYgAgtyw",
        date: "2023.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "04 나만의 유튜브 사이트 만들기",
        img: youtube04,
        author: "webstoryboy",
        videoId: "OKZXYgAgtyw",
        date: "2023.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },{
        title: "05 나만의 유튜브 사이트 만들기",
        img: youtube05,
        author: "webstoryboy",
        videoId: "OKZXYgAgtyw",
        date: "2023.09.09",
        channelId: "UCsvQSv7EeCMHyYb9ENKAJZw",
    },
]