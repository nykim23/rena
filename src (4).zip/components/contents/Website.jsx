import React from 'react'


import { websiteText } from '../../data/website'
import { Link } from 'react-router-dom'


const Website = () => {
    return (
        <section id="website">
            <div className='video__inner'>
                
            </div>
        </section>
        
    )
}

export default Website